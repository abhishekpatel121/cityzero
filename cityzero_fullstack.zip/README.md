# CityZero — Zero-Waste Urban Management System

## Quick start (local)

1. Install Node.js (18+), Docker & Docker Compose, or run services locally.
2. Copy `.env.example` files to `.env` and set values (especially JWT_SECRET).
3. Using Docker:
   ```
   docker-compose up --build
   ```
   - Backend: http://localhost:5000
   - Frontend: http://localhost:5173 (or http://localhost:3000 if docker mapped)

4. Or run locally:
   - Backend:
     ```
     cd backend
     npm install
     npm run seed
     npm run dev
     ```
   - Frontend:
     ```
     cd frontend
     npm install
     npm run dev
     ```

## Notes
- This scaffold provides core APIs, React frontend, and basic charts.
- You should run `npm install` in both backend and frontend to install dependencies.
- Tailwind requires postcss build; the frontend package.json includes devDependencies for it.

