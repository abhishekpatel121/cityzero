import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Leaderboard from './pages/Leaderboard';
import SubmitWaste from './pages/SubmitWaste';
import Login from './pages/Login';

export default function App(){
  return (
    <div className="min-h-screen">
      <header className="bg-green-600 text-white p-4">
        <div className="max-w-6xl mx-auto flex justify-between">
          <div className="font-bold">CityZero</div>
          <nav className="space-x-3">
            <Link to="/">Dashboard</Link>
            <Link to="/leaderboard">Leaderboard</Link>
            <Link to="/submit">Submit</Link>
            <Link to="/login">Login</Link>
          </nav>
        </div>
      </header>
      <main className="p-4 max-w-6xl mx-auto">
        <Routes>
          <Route path="/" element={<Dashboard/>} />
          <Route path="/leaderboard" element={<Leaderboard/>} />
          <Route path="/submit" element={<SubmitWaste/>} />
          <Route path="/login" element={<Login/>} />
        </Routes>
      </main>
    </div>
  );
}
