import React, { useState } from 'react';
import api, { setToken } from '../services/api';

export default function Login(){
  const [form,setForm] = useState({ email:'', password:'' });
  async function submit(e){ e.preventDefault(); try{ const res = await api.post('/auth/login', form); const token = res.data.token; setToken(token); localStorage.setItem('cityzero_token', token); alert('Logged in'); }catch(e){ alert('Login failed'); } }
  return (
    <form onSubmit={submit} className="max-w-md space-y-3 bg-white p-4 rounded shadow">
      <input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="Email" className="w-full p-2 rounded border" />
      <input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="Password" className="w-full p-2 rounded border" />
      <button className="bg-blue-600 text-white px-4 py-2 rounded">Login</button>
    </form>
  );
}
