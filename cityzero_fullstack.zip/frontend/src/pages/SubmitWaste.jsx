import React, { useState } from 'react';
import api from '../services/api';

export default function SubmitWaste(){
  const [form, setForm] = useState({ type: 'recycle', weightKg: '', neighborhood: '', description: '' });
  async function submit(e){ e.preventDefault(); try{ await api.post('/events', form); alert('Submitted — thanks!'); setForm({ type: 'recycle', weightKg: '', neighborhood: '', description: '' }); }catch(err){ alert('Error: '+(err?.response?.data?.message || err.message)); } }
  return (
    <form onSubmit={submit} className="max-w-md space-y-3 bg-white p-4 rounded shadow">
      <select value={form.type} onChange={e=>setForm({...form,type:e.target.value})} className="w-full p-2 rounded border">
        <option value="recycle">Recycle</option>
        <option value="compost">Compost</option>
        <option value="landfill">Landfill</option>
      </select>
      <input type="number" step="0.1" value={form.weightKg} onChange={e=>setForm({...form,weightKg:e.target.value})} placeholder="Weight (kg)" className="w-full p-2 rounded border" />
      <input value={form.neighborhood} onChange={e=>setForm({...form,neighborhood:e.target.value})} placeholder="Neighborhood" className="w-full p-2 rounded border" />
      <textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Notes (optional)" className="w-full p-2 rounded border" />
      <button className="bg-green-600 text-white px-4 py-2 rounded">Submit</button>
    </form>
  );
}
