import React, { useEffect, useState } from 'react';
import api from '../services/api';

export default function Leaderboard(){
  const [leaders, setLeaders] = useState([]);
  useEffect(()=>{ async function load(){ try{ const res = await api.get('/metrics/neighborhoods/top?limit=10'); setLeaders(res.data);}catch(e){console.error(e);} } load(); },[]);
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Top neighborhoods</h2>
      <ul className="space-y-2">
        {leaders.map((l,i)=>(
          <li key={i} className="bg-white p-3 rounded shadow flex justify-between">
            <div>
              <div className="font-medium">{l._id || 'Unknown'}</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-semibold">{Math.round(l.totalKg)}</div>
              <div className="text-sm">kg</div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
