import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function Dashboard(){
  const [summary, setSummary] = useState(null);
  useEffect(()=>{ async function load(){ try{ const res = await api.get('/metrics/summary?period=30d'); setSummary(res.data);}catch(e){console.error(e);} } load(); },[]);
  if(!summary) return <div>Loading...</div>;
  const data = {
    labels: summary.labels,
    datasets: [
      { label: 'Recycle (kg)', data: summary.recycle },
      { label: 'Compost (kg)', data: summary.compost },
      { label: 'Landfill (kg)', data: summary.landfill },
    ]
  };
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Last 30 days</h2>
      <div className="bg-white p-4 rounded shadow">
        <Bar data={data} />
      </div>
    </div>
  );
}
