const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const authRoutes = require('./routes/auth.routes');
const eventsRoutes = require('./routes/events.routes');
const metricsRoutes = require('./routes/metrics.routes');

const errorMiddleware = require('./middleware/error.middleware');

const app = express();
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// routes
app.use('/api/auth', authRoutes);
app.use('/api/events', eventsRoutes);
app.use('/api/metrics', metricsRoutes);

app.use(errorMiddleware);

module.exports = app;
