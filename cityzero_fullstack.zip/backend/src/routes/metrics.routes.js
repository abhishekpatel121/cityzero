const express = require('express');
const router = express.Router();
const MetricsController = require('../controllers/metrics.controller');

router.get('/summary', MetricsController.summary);
router.get('/neighborhoods/top', MetricsController.topNeighborhoods);

module.exports = router;
