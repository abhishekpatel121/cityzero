const express = require('express');
const router = express.Router();
const EventsController = require('../controllers/events.controller');
const { authMiddleware } = require('../middleware/auth.middleware');

router.post('/', authMiddleware, EventsController.createEvent);
router.get('/', EventsController.listEvents);
router.post('/:id/upvote', authMiddleware, EventsController.upvote);
router.post('/:id/verify', authMiddleware, EventsController.verifyEvent);

module.exports = router;
