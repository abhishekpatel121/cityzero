require('dotenv').config();
const connectDB = require('../config/db');
const User = require('../models/User');
const WasteEvent = require('../models/WasteEvent');

async function seed() {
  await connectDB();
  await User.deleteMany({});
  await WasteEvent.deleteMany({});

  const users = await User.insertMany([
    { name: 'Mayor', email: 'admin@cityzero.com', password: 'admin123', role: 'admin', neighborhood: 'Central' },
    { name: 'Anita', email: 'anita@example.com', password: 'anita123', neighborhood: 'North' },
    { name: 'Ravi', email: 'ravi@example.com', password: 'ravi123', neighborhood: 'South' }
  ]);

  await WasteEvent.insertMany([
    { type: 'recycle', weightKg: 5, neighborhood: 'North', reporter: users[1]._id, verified: true },
    { type: 'compost', weightKg: 2.5, neighborhood: 'South', reporter: users[2]._id },
    { type: 'landfill', weightKg: 20, neighborhood: 'Central', reporter: users[0]._id, verified: true },
  ]);

  console.log('Seeded DB');
  process.exit(0);
}

seed();
