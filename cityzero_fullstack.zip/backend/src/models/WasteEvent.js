const mongoose = require('mongoose');

const WasteEventSchema = new mongoose.Schema({
  type: { type: String, enum: ['recycle','compost','landfill'], required: true },
  weightKg: { type: Number, required: true, default: 0 },
  location: {
    lat: Number,
    lng: Number
  },
  neighborhood: String,
  description: String,
  reporter: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  verified: { type: Boolean, default: false },
  upvotes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  imageUrl: String
}, { timestamps: true });

module.exports = mongoose.model('WasteEvent', WasteEventSchema);
