const WasteEvent = require('../models/WasteEvent');
const mongoose = require('mongoose');

exports.summary = async (req, res, next) => {
  try {
    // simple aggregation: sum by type per day for last N days
    const period = req.query.period || '30d';
    const days = period.endsWith('d') ? parseInt(period.replace('d','')) : 30;
    const from = new Date();
    from.setDate(from.getDate() - days);

    const rows = await WasteEvent.aggregate([
      { $match: { createdAt: { $gte: from } } },
      { $project: { type:1, weightKg:1, day: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } } } },
      { $group: { _id: { day:"$day", type:"$type" }, total: { $sum: "$weightKg" } } },
      { $sort: { "_id.day": 1 } }
    ]);

    // pivot rows to labels + arrays for each type
    const map = {};
    const labelsSet = new Set();
    rows.forEach(r => {
      const day = r._id.day;
      labelsSet.add(day);
      map[day] = map[day] || { recycle:0, compost:0, landfill:0 };
      map[day][r._id.type] = r.total;
    });
    const labels = Array.from(labelsSet).sort();
    const recycle = labels.map(d => (map[d]||{}).recycle || 0);
    const compost = labels.map(d => (map[d]||{}).compost || 0);
    const landfill = labels.map(d => (map[d]||{}).landfill || 0);

    res.json({ labels, recycle, compost, landfill });
  } catch (err) { next(err); }
};

exports.topNeighborhoods = async (req, res, next) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const rows = await WasteEvent.aggregate([
      { $group: { _id: "$neighborhood", totalKg: { $sum: "$weightKg" } } },
      { $sort: { totalKg: -1 } },
      { $limit: limit }
    ]);
    res.json(rows);
  } catch (err) { next(err); }
};
