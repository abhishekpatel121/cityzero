const WasteEvent = require('../models/WasteEvent');
const User = require('../models/User');

exports.createEvent = async (req, res, next) => {
  try {
    const { type, weightKg, location, neighborhood, description } = req.body;
    const ev = new WasteEvent({
      type, weightKg, location, neighborhood, description, reporter: req.user.id
    });
    await ev.save();
    await User.findByIdAndUpdate(req.user.id, { $inc: { points: Math.round(weightKg) } });
    res.status(201).json(ev);
  } catch (err) { next(err); }
};

exports.listEvents = async (req, res, next) => {
  try {
    const { neighborhood, type, limit = 50 } = req.query;
    const filter = {};
    if (neighborhood) filter.neighborhood = neighborhood;
    if (type) filter.type = type;
    const events = await WasteEvent.find(filter).sort({ createdAt: -1 }).limit(parseInt(limit)).populate('reporter','name neighborhood');
    res.json(events);
  } catch (err) { next(err); }
};

exports.upvote = async (req, res, next) => {
  try {
    const ev = await WasteEvent.findById(req.params.id);
    if (!ev) return res.status(404).json({ message: 'Not found' });
    const already = ev.upvotes.some(id => id.equals(req.user.id));
    if (already) {
      ev.upvotes = ev.upvotes.filter(id => !id.equals(req.user.id));
      await ev.save();
      return res.json(ev);
    }
    ev.upvotes.push(req.user.id);
    await ev.save();
    res.json(ev);
  } catch (err) { next(err); }
};

exports.verifyEvent = async (req, res, next) => {
  try {
    const ev = await WasteEvent.findByIdAndUpdate(req.params.id, { verified: true }, { new: true });
    res.json(ev);
  } catch (err) { next(err); }
};
